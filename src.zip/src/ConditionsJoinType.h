#pragma once 

enum class ConditionsJoinType
{
	AND,
	OR
};